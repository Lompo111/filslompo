// =============================================================================
// Script Google Earth Engine — Téléchargement Sentinel-2
// Suivi de la déforestation au Burkina Faso
//
// UTILISATION :
//   1. Ouvrir code.earthengine.google.com
//   2. Coller ce script
//   3. Adapter la zone d'etude (geometry)
//   4. Cliquer Run puis Export
// =============================================================================

// -----------------------------------------------------------------------------
// 1. ZONE D'ETUDE
//    Remplacer par les coordonnees de votre zone
//    Exemple : Foret classee de Nazinon (Burkina Faso)
// -----------------------------------------------------------------------------

var geometry = ee.Geometry.Rectangle([
  -2.5,   // longitude ouest
  11.5,   // latitude sud
  -1.5,   // longitude est
  12.5    // latitude nord
]);
// <- ADAPTER CES COORDONNEES A VOTRE ZONE

Map.centerObject(geometry, 10);
Map.addLayer(geometry, {color: 'red'}, 'Zone etude');

// -----------------------------------------------------------------------------
// 2. FONCTION DE TRAITEMENT SENTINEL-2
//    - Filtre nuages (QA60)
//    - Composite mediane sur la saison seche (Nov-Fev)
//    - Bandes : B2, B3, B4, B8, B11 (blue, green, red, nir, swir1)
// -----------------------------------------------------------------------------

function getS2Image(year) {
  // Saison seche : novembre annee-1 a fevrier annee
  var startDate = ee.Date.fromYMD(year - 1, 11, 1);
  var endDate   = ee.Date.fromYMD(year, 3, 1);

  var collection = ee.ImageCollection('COPERNICUS/S2_SR_HARMONIZED')
    .filterBounds(geometry)
    .filterDate(startDate, endDate)
    .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20))
    .select(['B2', 'B3', 'B4', 'B8', 'B11']);

  // Composite mediane pour reduire les nuages residuels
  var composite = collection.median().clip(geometry);

  print('Nb images ' + year + ' :', collection.size());

  return composite;
}

// -----------------------------------------------------------------------------
// 3. CREATION DES COMPOSITES PAR DATE
// -----------------------------------------------------------------------------

var s2_2017 = getS2Image(2017);
var s2_2020 = getS2Image(2020);
var s2_2023 = getS2Image(2023);
// Note : 2026 pas encore disponible — utiliser 2024 ou 2025

// Parametres de visualisation (composition infrarouge NIR-Red-Green)
var visParams = {
  bands: ['B8', 'B4', 'B3'],
  min: 0,
  max: 3000,
  gamma: 1.4
};

Map.addLayer(s2_2017, visParams, 'S2 2017 (Infrarouge)');
Map.addLayer(s2_2020, visParams, 'S2 2020 (Infrarouge)');
Map.addLayer(s2_2023, visParams, 'S2 2023 (Infrarouge)');

// -----------------------------------------------------------------------------
// 4. CALCUL DU NDVI PAR DATE (optionnel — pour visualisation)
// -----------------------------------------------------------------------------

function calcNDVI(img) {
  return img.normalizedDifference(['B8', 'B4']).rename('NDVI');
}

var ndvi_2017 = calcNDVI(s2_2017);
var ndvi_2020 = calcNDVI(s2_2020);
var ndvi_2023 = calcNDVI(s2_2023);

var ndviVis = {min: -0.2, max: 0.8, palette: ['brown', 'yellow', 'green', 'darkgreen']};
Map.addLayer(ndvi_2017, ndviVis, 'NDVI 2017', false);
Map.addLayer(ndvi_2020, ndviVis, 'NDVI 2020', false);
Map.addLayer(ndvi_2023, ndviVis, 'NDVI 2023', false);

// Changement NDVI 2017 -> 2023 (negatif = deforestation)
var ndvi_change = ndvi_2023.subtract(ndvi_2017).rename('NDVI_change');
Map.addLayer(ndvi_change,
  {min: -0.5, max: 0.5, palette: ['red', 'white', 'green']},
  'Changement NDVI 2017-2023');

// -----------------------------------------------------------------------------
// 5. EXPORT DES IMAGES VERS GOOGLE DRIVE
//    Les fichiers seront dans : Google Drive/deforestation_burkina/
// -----------------------------------------------------------------------------

var exportParams = {
  scale: 10,              // resolution 10m (Sentinel-2)
  region: geometry,
  crs: 'EPSG:32630',     // UTM zone 30N (Burkina Faso)
  fileFormat: 'GeoTIFF',
  maxPixels: 1e13,
  folder: 'deforestation_burkina'
};

// Exporter 2017
Export.image.toDrive(Object.assign({}, exportParams, {
  image: s2_2017,
  description: 'S2_2017',
  fileNamePrefix: 'S2_2017'
}));

// Exporter 2020
Export.image.toDrive(Object.assign({}, exportParams, {
  image: s2_2020,
  description: 'S2_2020',
  fileNamePrefix: 'S2_2020'
}));

// Exporter 2023
Export.image.toDrive(Object.assign({}, exportParams, {
  image: s2_2023,
  description: 'S2_2023',
  fileNamePrefix: 'S2_2023'
}));

print('Exports lances — verifier l\'onglet Tasks pour suivre le progres');
