# =============================================================================
# config.py  —  Pipeline Suivi Déforestation @ Burkina Faso
#
# UTILISATION :
#   Placer ce fichier dans :
#     - deforestation/config.py
#     - deforestation/utils/config.py (si necessaire)
#
#   Dans chaque notebook, ajouter en premiere cellule :
#     import sys, os
#     os.chdir(r'C:\Users\HP\Desktop\ideal\deforestation')
#     sys.path.insert(0, r'C:\Users\HP\Desktop\ideal\deforestation')
#     sys.path.insert(0, r'C:\Users\HP\Desktop\ideal\deforestation\utils')
#     import importlib, config
#     importlib.reload(config)
#     from config import *
# =============================================================================

import os, sys

# -----------------------------------------------------------------------------
# 0. CHEMINS DU PROJET
# -----------------------------------------------------------------------------

REPO  = r'C:\Users\HP\Desktop\ideal\deforestation'
UTILS = os.path.join(REPO, 'utils')

if REPO  not in sys.path: sys.path.insert(0, REPO)
if UTILS not in sys.path: sys.path.insert(0, UTILS)

# -----------------------------------------------------------------------------
# 1. CHEMINS PRINCIPAUX
# -----------------------------------------------------------------------------

BASE         = r'C:\Users\HP\Desktop\ideal\deforestation'

IMAGES_DIR   = os.path.join(BASE, 'images')      # images GEE telechargees
VECTEUR_DIR  = os.path.join(BASE, 'vecteur')     # limites zone d'etude
EXTERNAL_DIR = os.path.join(BASE, 'external')    # verite terrain, MNT

data_root    = os.path.join(BASE, 'data') + '\\'
place        = 'burkina_foret'                   # <- adapter au nom de la zone
data_path    = data_root + place + '\\'
models_dir   = data_root + 'models\\'

# -----------------------------------------------------------------------------
# 2. IMAGES SENTINEL-2 (4 dates)
#    Telechargees depuis Google Earth Engine
#    Nommage : S2_YYYY.tif
# -----------------------------------------------------------------------------

local_images = {
    '2017': os.path.join(IMAGES_DIR, 'S2_2017.tif'),
    '2020': os.path.join(IMAGES_DIR, 'S2_2020.tif'),
    '2023': os.path.join(IMAGES_DIR, 'S2_2023.tif'),
    '2026': os.path.join(IMAGES_DIR, 'S2_2026.tif'),
}
image_suffix = '2017'   # <- changer selon la date traitee

# Verite terrain
verite_terrain_shp            = os.path.join(EXTERNAL_DIR, 'verite_terrain.shp')
verite_terrain_nouvelle_shp   = os.path.join(EXTERNAL_DIR, 'verite_terrain_nouvelle.shp')
verite_terrain_classified_shp = os.path.join(EXTERNAL_DIR, 'verite_terrain_classified.shp')

# Zone d'etude
place_title     = place.title()
place_shapefile = os.path.join(data_path, 'gt',
                               place_title + '_studyAreaEPSG4326.shp')

# -----------------------------------------------------------------------------
# 3. PARAMETRES DE TUILAGE
# -----------------------------------------------------------------------------

tile_resolution  = 10      # Sentinel-2 = 10m
tile_size        = 256
tile_pad         = 32
resolution       = tile_resolution
source           = 's2'
suffix           = 'BGRNS1S2A'
processing_level = 'none'

# -----------------------------------------------------------------------------
# 4. BANDES SENTINEL-2
#    Ordre : B2(blue), B3(green), B4(red), B8(nir), B11(swir1)
# -----------------------------------------------------------------------------

BAND_ORDER = {
    'blue' : 0,   # B2  - 490 nm
    'green': 1,   # B3  - 560 nm
    'red'  : 2,   # B4  - 665 nm
    'nir'  : 3,   # B8  - 842 nm
    'swir1': 4,   # B11 - 1610 nm
}
s2_bands = list(BAND_ORDER.keys())
n_bands  = len(s2_bands)

# -----------------------------------------------------------------------------
# 5. CLASSES LULC — DEFORESTATION
#    Adapter selon la zone d'etude
# -----------------------------------------------------------------------------

label_suffix   = 'gt'
label_lot      = '0'
burn_attribute = 'Name'

category_label = {
    0  : 'Foret dense',          # foret intacte, couvert > 70%
    1  : 'Foret degradee',       # foret perturbee, couvert 30-70%
    2  : 'Agriculture',          # champs, cultures, jacheres
    3  : 'Sol nu',               # terres nues, zones degradees
    4  : 'Eau',                  # cours d'eau, mares, retenues
    5  : 'Savane / Brousse',     # vegetation arbustive
    254: 'Hors donnees',
    255: 'Sans label',
}

# Correspondance nom shapefile -> code numerique
name_to_class = {
    # Foret dense
    'Foret dense'         : 0,
    'Foret'               : 0,
    'Dense forest'        : 0,
    # Foret degradee
    'Foret degradee'      : 1,
    'Foret claire'        : 1,
    'Degraded forest'     : 1,
    # Agriculture
    'Agriculture'         : 2,
    'Culture'             : 2,
    'Champ'               : 2,
    'Jachère'             : 2,
    'Jachere'             : 2,
    # Sol nu
    'Sol nu'              : 3,
    'Bare soil'           : 3,
    'Zone degradee'       : 3,
    # Eau
    'Eau'                 : 4,
    'Cours d\'eau'       : 4,
    'Mare'                : 4,
    'Retenue'             : 4,
    # Savane
    'Savane'              : 5,
    'Brousse'             : 5,
    'Vegetation'          : 5,
    'Savane arbustive'    : 5,
    'Savane arboree'      : 5,
}

# -----------------------------------------------------------------------------
# 6. MODELE CNN
# -----------------------------------------------------------------------------

model_id                  = 'foret_s2_cnn_v1'  # <- changer a chaque run
network_filename          = models_dir + model_id + '.keras'
weights_fast_path         = models_dir + model_id + '.weights.h5'
weights_slow_path         = models_dir + model_id + '_slow.weights.h5'
category_weights_filename = models_dir + model_id + '_category_weights.pkl'

catalog_path = data_root + place + '_chip_catalog.csv'
path_train   = models_dir + model_id + '_train.csv'
path_valid   = models_dir + model_id + '_valid.csv'

# -----------------------------------------------------------------------------
# 7. UTILITAIRES
# -----------------------------------------------------------------------------

def create_dirs():
    """Cree l'arborescence de dossiers."""
    dirs = [
        data_path,
        os.path.join(data_path, 'gt'),
        os.path.join(data_path, 'imagery', 'none'),
        os.path.join(data_path, 'maps'),
        models_dir,
        IMAGES_DIR,
        VECTEUR_DIR,
        EXTERNAL_DIR,
    ]
    for d in dirs:
        os.makedirs(d, exist_ok=True)
        print(f'  OK  {d}')

def check_files():
    """Verifie que tous les fichiers sources sont accessibles."""
    try:
        import rasterio, fiona
        print('\n--- Images Sentinel-2 ---')
        for k, p in local_images.items():
            if os.path.exists(p):
                with rasterio.open(p) as s:
                    print(f'  {k} : {s.width}x{s.height} | {s.count} bandes | EPSG:{s.crs.to_epsg() if s.crs else "None"}')
            else:
                print(f'  MANQUANT : {p}')

        print('\n--- Verite terrain ---')
        for label, path in [
            ('Nouvelle', verite_terrain_nouvelle_shp),
            ('Classifiee', verite_terrain_classified_shp),
        ]:
            if os.path.exists(path):
                with fiona.open(path) as f:
                    print(f'  {label:12s} : {len(f)} entites | CRS : {f.crs}')
            else:
                print(f'  {label:12s} : MANQUANT')
    except ImportError as e:
        print(f'Erreur import : {e}')

if __name__ == '__main__':
    print('=== Creation des dossiers ===')
    create_dirs()
    print('\n=== Verification des fichiers ===')
    check_files()
