# =============================================================================
# analyse_deforestation.py
# Analyse des changements de couverture forestiere entre les dates
#
# UTILISATION :
#   Executer dans un notebook ou terminal apres la cartographie
#   Produit : tableaux de statistiques + cartes de changement
# =============================================================================

import sys, os
sys.path.insert(0, r'C:\Users\HP\Desktop\ideal\deforestation')
sys.path.insert(0, r'C:\Users\HP\Desktop\ideal\deforestation\utils')

import importlib, config
importlib.reload(config)
from config import *

import numpy as np
import rasterio
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import pandas as pd
import json

# Palette de couleurs
COLORS = {
    0  : [0,   100, 0],    # Foret dense     -> vert fonce
    1  : [144, 238, 144],  # Foret degradee  -> vert clair
    2  : [255, 215, 0],    # Agriculture     -> jaune
    3  : [210, 180, 140],  # Sol nu          -> beige
    4  : [30,  144, 255],  # Eau             -> bleu
    5  : [205, 133, 63],   # Savane/Brousse  -> marron
    255: [255, 255, 255],  # No data         -> blanc
}

def load_map(year):
    """Charge la carte LULC d'une annee."""
    path = os.path.join(
        data_path, 'maps',
        f'{place}_{model_id}_{year}_lulc.tif'
    )
    if not os.path.exists(path):
        print(f'MANQUANT : {path}')
        return None
    with rasterio.open(path) as src:
        return src.read(1)

def map_to_rgb(lulc):
    """Convertit une carte LULC en image RGB."""
    rgb = np.zeros((lulc.shape[0], lulc.shape[1], 3), dtype='uint8')
    for val, color in COLORS.items():
        rgb[lulc == val] = color
    return rgb

def calc_stats(lulc, year):
    """Calcule les statistiques de surface par classe."""
    total_pixels = np.sum(lulc != 255)
    stats = {}
    for code, nom in category_label.items():
        if code >= 254:
            continue
        n = int(np.sum(lulc == code))
        surface_ha = n * tile_resolution * tile_resolution / 10000
        pct = 100.0 * n / total_pixels if total_pixels > 0 else 0
        stats[nom] = {
            'code'       : code,
            'pixels'     : n,
            'surface_ha' : round(surface_ha, 1),
            'pourcentage': round(pct, 2),
        }
    return stats

def calc_changement(lulc_avant, lulc_apres):
    """Calcule les pixels qui ont change de classe."""
    # Pixels deforestes : Foret dense(0) ou Foret degradee(1) -> autre classe
    deforeste = (
        ((lulc_avant == 0) | (lulc_avant == 1)) &
        ((lulc_apres != 0) & (lulc_apres != 1)) &
        (lulc_apres != 255)
    )
    # Pixels reforestes : autre -> Foret dense(0) ou Foret degradee(1)
    reforeste = (
        ((lulc_apres == 0) | (lulc_apres == 1)) &
        ((lulc_avant != 0) & (lulc_avant != 1)) &
        (lulc_avant != 255)
    )
    surface_deforestee = float(np.sum(deforeste)) * tile_resolution**2 / 10000
    surface_reforestee = float(np.sum(reforeste)) * tile_resolution**2 / 10000
    return deforeste, reforeste, surface_deforestee, surface_reforestee

# -----------------------------------------------------------------------
# EXECUTION PRINCIPALE
# -----------------------------------------------------------------------

if __name__ == '__main__':

    dates = ['2017', '2020', '2023']
    maps  = {}

    print('=== Chargement des cartes LULC ===')
    for year in dates:
        m = load_map(year)
        if m is not None:
            maps[year] = m
            print(f'  {year} : {m.shape}')

    if len(maps) < 2:
        print('ERREUR : au moins 2 cartes necessaires')
        exit()

    # -----------------------------------------------------------------------
    # STATISTIQUES PAR DATE
    # -----------------------------------------------------------------------

    print('\n=== Statistiques de surface par date ===')
    all_stats = {}
    for year, lulc in maps.items():
        stats = calc_stats(lulc, year)
        all_stats[year] = stats
        print(f'\n{year}:')
        for nom, s in stats.items():
            print(f'  {nom:25s} : {s["surface_ha"]:10.1f} ha ({s["pourcentage"]:5.1f}%)')

    # Sauvegarder en JSON
    stats_path = os.path.join(models_dir, 'statistiques_deforestation.json')
    with open(stats_path, 'w', encoding='utf-8') as f:
        json.dump(all_stats, f, indent=4, ensure_ascii=False)
    print(f'\nStatistiques sauvegardees : {stats_path}')

    # -----------------------------------------------------------------------
    # ANALYSE DES CHANGEMENTS
    # -----------------------------------------------------------------------

    print('\n=== Analyse des changements ===')
    years_list = sorted(maps.keys())
    for i in range(len(years_list) - 1):
        y1, y2 = years_list[i], years_list[i+1]
        defo, refo, surf_defo, surf_refo = calc_changement(maps[y1], maps[y2])
        print(f'\n{y1} -> {y2}:')
        print(f'  Deforestation : {surf_defo:.1f} ha')
        print(f'  Reforestation : {surf_refo:.1f} ha')
        print(f'  Bilan net     : {surf_refo - surf_defo:.1f} ha')

    # -----------------------------------------------------------------------
    # VISUALISATION
    # -----------------------------------------------------------------------

    print('\n=== Generation des cartes ===')

    n_dates = len(maps)
    fig, axes = plt.subplots(1, n_dates, figsize=(6 * n_dates, 8))
    if n_dates == 1:
        axes = [axes]

    for ax, (year, lulc) in zip(axes, sorted(maps.items())):
        rgb = map_to_rgb(lulc)
        ax.imshow(rgb)
        ax.set_title(f'LULC {year}', fontsize=14, fontweight='bold')
        ax.axis('off')

    # Legende
    patches = [
        mpatches.Patch(color=[c/255 for c in COLORS[code]], label=nom)
        for code, nom in category_label.items()
        if code < 254
    ]
    fig.legend(handles=patches, loc='lower center',
               ncol=3, fontsize=9, bbox_to_anchor=(0.5, -0.02))

    plt.suptitle(f'Suivi de la déforestation — {place}', fontsize=16, y=1.02)
    plt.tight_layout()

    fig_path = os.path.join(data_path, 'maps', 'comparaison_deforestation.png')
    plt.savefig(fig_path, dpi=150, bbox_inches='tight')
    plt.show()
    print(f'Figure sauvegardee : {fig_path}')

    # -----------------------------------------------------------------------
    # GRAPHIQUE EVOLUTION DES SURFACES
    # -----------------------------------------------------------------------

    fig2, ax = plt.subplots(figsize=(10, 6))
    classes_a_afficher = ['Foret dense', 'Foret degradee', 'Agriculture', 'Sol nu']
    colors_plot = ['darkgreen', 'lightgreen', 'gold', 'tan']

    for nom, color in zip(classes_a_afficher, colors_plot):
        surfaces = [all_stats[y].get(nom, {}).get('surface_ha', 0)
                    for y in sorted(maps.keys())]
        ax.plot(sorted(maps.keys()), surfaces, marker='o',
                label=nom, color=color, linewidth=2, markersize=8)

    ax.set_xlabel('Annee', fontsize=12)
    ax.set_ylabel('Surface (ha)', fontsize=12)
    ax.set_title(f'Evolution des surfaces — {place}', fontsize=14)
    ax.legend(fontsize=10)
    ax.grid(True, alpha=0.3)

    graph_path = os.path.join(data_path, 'maps', 'evolution_surfaces.png')
    plt.savefig(graph_path, dpi=150, bbox_inches='tight')
    plt.show()
    print(f'Graphique sauvegarde : {graph_path}')
