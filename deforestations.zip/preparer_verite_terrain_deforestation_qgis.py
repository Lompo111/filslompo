# =============================================================================
# preparer_verite_terrain_deforestation_qgis.py
# Script pour la CONSOLE PYTHON DE QGIS
#
# Charge les images en composition infrarouge et cree un shapefile
# vide pour numeriser la verite terrain deforestation
# =============================================================================

from qgis.core import (
    QgsProject, QgsRasterLayer, QgsVectorLayer,
    QgsField, QgsFields, QgsWkbTypes,
    QgsCoordinateReferenceSystem,
    QgsVectorFileWriter
)
from qgis.PyQt.QtCore import QVariant
from qgis import processing
import os

# -----------------------------------------------------------------------------
# CHEMINS — adapter selon votre zone
# -----------------------------------------------------------------------------

IMAGES_DIR   = r'C:\Users\HP\Desktop\ideal\deforestation\images'
EXTERNAL_DIR = r'C:\Users\HP\Desktop\ideal\deforestation\external'
SHP_OUT      = os.path.join(EXTERNAL_DIR, 'verite_terrain_nouvelle.shp')

# Assurer que le dossier existe
os.makedirs(EXTERNAL_DIR, exist_ok=True)

# Classes LULC deforestation
CLASSES = {
    0: 'Foret dense',
    1: 'Foret degradee',
    2: 'Agriculture',
    3: 'Sol nu',
    4: 'Eau',
    5: 'Savane / Brousse',
}

print('=== Chargement des images ===')

# Charger les 3 images en infrarouge couleur (NIR=B8, Red=B4, Green=B3)
images_chargees = []
for year in ['2017', '2020', '2023']:
    tif_path = os.path.join(IMAGES_DIR, f'S2_{year}.tif')
    if os.path.exists(tif_path):
        layer = QgsRasterLayer(tif_path, f'S2_{year} - Infrarouge')
        if layer.isValid():
            from qgis.core import QgsMultiBandColorRenderer
            renderer = QgsMultiBandColorRenderer(
                layer.dataProvider(), 4, 3, 2)  # NIR, Red, Green
            layer.setRenderer(renderer)
            layer.triggerRepaint()
            QgsProject.instance().addMapLayer(layer)
            images_chargees.append(year)
            print(f'  {year} charge')
    else:
        print(f'  MANQUANT : {tif_path}')

# Creer le shapefile de verite terrain
print('\n=== Creation du shapefile ===')

# Utiliser le CRS de la premiere image chargee
crs = QgsCoordinateReferenceSystem('EPSG:32630')

fields = QgsFields()
fields.append(QgsField('Name',     QVariant.String, len=50))
fields.append(QgsField('class_id', QVariant.Int))
fields.append(QgsField('date',     QVariant.String, len=10))

writer = QgsVectorFileWriter(
    SHP_OUT, 'UTF-8', fields,
    QgsWkbTypes.Polygon, crs, 'ESRI Shapefile'
)

if writer.hasError() != QgsVectorFileWriter.NoError:
    print('ERREUR : ' + str(writer.hasError()))
else:
    print('Shapefile cree : ' + SHP_OUT)
del writer

# Charger et activer l'edition
vt_layer = QgsVectorLayer(SHP_OUT, 'Verite terrain deforestation', 'ogr')
QgsProject.instance().addMapLayer(vt_layer)
vt_layer.startEditing()

print(f"""
=============================================================
PRET A NUMERISER !
=============================================================

COMPOSITION COLOREE INFRAROUGE :
  ROUGE VIF    -> Foret dense (NDVI eleve)
  ROUGE SOMBRE -> Foret degradee / Savane
  CYAN / BLANC -> Sol nu, zones agricoles
  NOIR / BLEU  -> Eau
  BEIGE / GRIS -> Sol nu, terres degradees

CLASSES DISPONIBLES :
  0 = Foret dense
  1 = Foret degradee
  2 = Agriculture
  3 = Sol nu
  4 = Eau
  5 = Savane / Brousse

COLONNE "date" : annee de reference (ex: 2017)

CONSEIL :
  - Utiliser S2_2017 comme reference principale
  - Dessiner 20+ polygones par classe
  - Bien repartir sur toute la zone
  - Eviter les zones de transition floues

Fichier : {SHP_OUT}
=============================================================
""")
